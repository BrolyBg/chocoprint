# website05


## Contexte

Vous accueillez un stagiaire en tant que tuteur dans votre entreprise. Il vient juste d'installer Xampp.


## Travail à faire

Le stagiaire souhaitait améliorer le rendu graphique de son site en utilisant les feuilles de style CSS. Rien ne fonctionne comme prévu, et sa page reste comme inchangée. 

Il vous demande de l'aide en vous donnant un screenshot du résultat qu'il a vu sur un autre site et qu'il aimerait obtenir. Il vous demande également de l'aider à indenter le code CSS qu'il a commencé à produire.

Une fois le travail terminé, vous compléterez le compte-rendu d'intervention ci-dessous.


## Compte-rendu de l'intervention

...TODO...
