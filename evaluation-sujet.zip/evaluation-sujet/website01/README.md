# website01


## Contexte

Vous accueillez un stagiaire en tant que tuteur dans votre entreprise.


## Travail à faire

Le stagiaire vous demande de l'aide pour indenter son code HTML. Son cahier des charges lui stipule qu'il faut utiliser des indentations d'un valeur de 2 caractères espaces.

Une fois le travail terminé, vous compléterez le compte-rendu d'intervention ci-dessous.


## Compte-rendu de l'intervention

...TODO...