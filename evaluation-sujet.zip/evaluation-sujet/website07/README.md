# website07


## Contexte

Vous accueillez un stagiaire en tant que tuteur dans votre entreprise. Il revient de déjeuner avec un de ses collègues de promotion qui lui a parlé de Bootstrap.


# Travail à faire

Le stagiaire souhaiterait finalement utiliser Bootstrap pour son site. Il vous demande de l'aide car il ne sait pas comment utiliser le système de grille pour positionner les éléments. Il souhaiterait réaliser quelque chose comme schématisé ci-dessous :
```
+--------------------------------------------------------------+
|                            Zone1                             |
+--------------------------------------------------------------+
|        Zone2       |       Zone3        |        Zone4       |
+--------------------------------------------------------------+
|             Zone5            |             Zone6             |
+--------------------------------------------------------------+
```

Il vous a fourni la page de documentation de Boostrap en scrrenshot.

Une fois le travail terminé, vous compléterez le compte-rendu d'intervention ci-dessous.


## Compte-rendu de l'intervention

...TODO...