# website08


## Contexte

Vous accueillez un stagiaire en tant que tuteur dans votre entreprise. Il vient de commencer un module Javascript sur un MOOC.


## Travail à faire

Le stagiaire a commencé sa formation Javascript, mais bloque sur un exercice. L'objectif est le suivant :
- un formulaire de saisie permet à l'utilisateur de saisir son nom
- un bouton permet de générer 10 messages personnalisés selon sa langue
- le titre change de couleur de rouge à bleu

Voir les screenshots `avant.png` et `apres.png` pour plus de détails

Une fois le travail terminé, vous compléterez le compte-rendu d'intervention ci-dessous.


## Compte-rendu de l'intervention

...TODO...

