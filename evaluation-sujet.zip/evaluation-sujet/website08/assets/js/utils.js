function generate() {
    // Get language and login values
    let language = document.getElementById("language").value;
    let login = // ...TODO...

    // Print to debug
    console.log(language + " " + login);

    // Message generation
    let message = "???" + login + "???";
    // ...TODO...

    // Loop to build the 10 messages
    let messages = "";        
    // ...TODO...

    // Print the 10 messages
    document.getElementById("response").innerHTML = "...TODO...";    

    // Change title color from red to blue
    // ...TODO...
}