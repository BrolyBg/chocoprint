# website03


## Contexte

Vous accueillez un stagiaire en tant que tuteur dans votre entreprise.


## Travail à faire

Le stagiaire vous demande de l'aide pour corriger ses liens, aucun ne semblent fonctionner correctement dans sa page `index.html`.

Une fois le travail terminé, vous compléterez le compte-rendu d'intervention ci-dessous.


## Compte-rendu de l'intervention

...TODO...