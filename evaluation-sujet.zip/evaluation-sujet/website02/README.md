# website02


## Contexte

Vous accueillez un stagiaire en tant que tuteur dans votre entreprise.


## Travail à faire

Le stagiaire vous demande de l'aide pour corriger son code HTML. En effet un de ses amis lui a suggéré de passer son code au "W3C Validator" et ce dernier lui a remonté de nombreux problèmes. Il compte sur vous pour corriger un maximum d'erreurs.

Une fois le travail terminé, vous compléterez le compte-rendu d'intervention ci-dessous.


## Compte-rendu de l'intervention

...TODO...