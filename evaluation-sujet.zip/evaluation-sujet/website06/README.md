# website06

## Contexte

Vous accueillez un stagiaire en tant que tuteur dans votre entreprise. Il vient juste de terminer une tutoriel vidéo sur Youtube.


# Travail à faire

Le stagiaire souhaiterait ajouter un menu à son site. On lui a recommandé d'utiliser une liste non énumérée HTML et du CSS. Alors qu'il tentait de changer les couleurs d'une entrée du menu quand la souris passe par dessus :
- couleur de fond = orange
- couleur du texte = noir
Subitement plus aucun menu de s'affiche, selon ses dires...

Il vous demande de l'aide avec un screenshot du tutoriel vidéo qu'il a suivi (le_menu_de_mes_reves.png)

Une fois le travail terminé, vous compléterez le compte-rendu d'intervention ci-dessous.


## Compte-rendu de l'intervention

...TODO...