# website04

## Contexte

Vous accueillez un stagiaire en tant que tuteur dans votre entreprise. Il vient juste d'installer Xampp.


# Travail à faire

Le stagiaire souhaitait ajouter un tableau avec les différents services de l'entreprise, mais ses images ne semblent pas s'afficher correctement. Il vous demande de l'aide.

Une fois le travail terminé, vous compléterez le compte-rendu d'intervention ci-dessous.


## Compte-rendu de l'intervention

...TODO...